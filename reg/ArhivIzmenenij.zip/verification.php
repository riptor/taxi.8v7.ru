<?php
// ver. 1.002.32
// 1:59 03.03.2016
// http://7v8.ru http://taxi.7v8.ru
// serg@7v8.ru
// кодер Чернухин Сергей

$myname=$_SERVER["SERVER_NAME"];;
$pagename="My Taxi.";
//--------- обявляем переменные. -----------------------
require_once($_SERVER['DOCUMENT_ROOT'].'/includes/config.php');
// finish --------- обявляем переменные. -----------------------

/* создать соединение */ 
$dbh = mysql_connect($hostnameSQL,$usernameSQL,$passwordSQL) or die("Не могу соединиться с MySQL.");
/* выбрать базу данных. Если произойдет ошибка - вывести ее */ 
mysql_select_db($dbNameSQL) or die(mysql_error()); 

	
    if (isset($_POST['submit'])){
		if(empty($_POST['login']))  {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Введите логин!"> Введите логин! </font>';
		} 
//		elseif (!preg_match("/^\w{3,}$/", $_POST['login'])) {
//			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="В поле "Логин" введены недопустимые символы!"> В поле "Логин" введены недопустимые символы! Только буквы, цифры и подчеркивание!</font>';
//		}
		elseif(empty($_POST['password'])) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Введите пароль !"> Введите пароль!</font>';
		}
		elseif (!preg_match("/\A(\w){6,20}\Z/", $_POST['password'])) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Пароль слишком короткий!"> Пароль слишком короткий! Пароль должен быть не менее 6 символов! </font>';
		}
		elseif(empty($_POST['password2'])) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Введите подтверждение пароля!"> Введите подтверждение пароля!</font>';
		}
		elseif($_POST['password'] != $_POST['password2']) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Введенные пароли не совпадают!"> Введенные пароли не совпадают!</font>';
		}
		
		
		 
		else{
			$login = $_POST['login'];
			$password = $_POST['password'];
			$mdPassword = sha1(sha1($password));//шифруем пароль двойной хеш.
			$password2 = $_POST['password2'];
			$pone = $_POST['pone'];
			$email = $_POST['email'];
			$rdate = date("d-m-Y в H:i");
			$name = $_POST['name'];
			$lastname = $_POST['lastname'];


// ----------------- invite --------------------------------
			$invite = $_POST['invite'];
//Выводит строку с указаным номером.
$query = "SELECT * FROM invite WHERE invite = $invite "; 
/* Выполнить запрос. Если произойдет ошибка - вывести ее. */ 
$res = mysql_query($query) or die(mysql_error());
$KolVO-invite = mysql_num_rows($res); 	/* Как много нашлось таких */ 
$row = mysql_fetch_array($res);
echo $row ['invite']." lubopitno ".$invite." kol-vo naideno ".$id;

	if ($row ['invite'] == $invite) {
echo $row ['invite']."klass";
		echo '<font color="red"><img border="0" src="error.gif" align="middle" alt="К сожалению такого invite (приглашения) нету."> К сожалению такого invite (приглашения) нету. :(</font>';
			}
else
{
echo $row ['invite']." slapa ";

	if ($row ['login'] == "null"){
	echo '<font color="red"><img border="0" src="error.gif" align="middle" alt="Это приглашение уже использовал '.$row ['login'].'> Это приглашение уже использовал '.$row ['login'].'</font>';
				}

	else {
		$query = "INSERT INTO invite (invite, login)
			VALUES ('$invite', '$login')";
			$result = mysql_query($query) or die(mysql_error());
		}
}
// finish ----------------- invite --------------------------------

  
			$query = ("SELECT id FROM users WHERE login='$login'");
			$sql = mysql_query($query) or die(mysql_error());
			
			if (mysql_num_rows($sql) > 0) {
				echo '<font color="red"><img border="0" src="error.gif" align="middle" alt="Пользователь с таким логином зарегистрированый!"> Пользователь с таким логином зарегистрирован!</font>';
			}
			else {
				$query2 = ("SELECT id FROM users WHERE email='$email'");
				$sql = mysql_query($query2) or die(mysql_error());
				if (mysql_num_rows($sql) > 0){
					echo '<font color="red"><img border="0" src="error.gif"  alt="Пользователь с таким e-mail зарегистрированый!"> Пользователь с таким e-mail уже зарегистрирован!</font>';
				}
				else{
					$ip = $_SERVER['REMOTE_ADDR'];		//ip адрес клиента.
					$query = "INSERT INTO users (login, pone, password, email, reg_date, ip, name_2, name_3, name_4, hash )
							  VALUES ('$login', '$pone', '$mdPassword', '$email', '$rdate', '$ip', '$name', '$lastname', '$name', '$hash')";
					$result = mysql_query($query) or die(mysql_error());;
					echo '<font color="green"><img border="0" src="ok.gif" align="middle" alt="Вы успешно зарегистрировались!"> Вы успешно зарегистрировались! Об открытии сайта мы уведомим вас по Email.</font><br><a href="index.php">На главную</a>';
					
								
				}
			}
		}
    }
?>